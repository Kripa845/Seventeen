from django.core.management import call_command
from rest_framework.test import APITestCase


class ApiTests(APITestCase):
    @classmethod
    def setUpTestData(cls):
        call_command("seed_svt", verbosity=0)

    def test_thirteen_members(self):
        res = self.client.get("/api/members/")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(len(res.data), 13)

    def test_filter_by_unit(self):
        res = self.client.get("/api/members/?unit=performance")
        self.assertEqual({m["slug"] for m in res.data}, {"jun", "hoshi", "the8", "dino"})

    def test_album_detail_has_songs_and_theme(self):
        res = self.client.get("/api/albums/fml/")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.data["songs"][0]["title"], "Super")
        self.assertIn("accent", res.data["theme"])

    def test_seed_is_idempotent(self):
        call_command("seed_svt", verbosity=0)
        self.assertEqual(len(self.client.get("/api/albums/").data), 21)
        self.assertEqual(len(self.client.get("/api/songs/").data), 21)

    def test_post_and_list_scores(self):
        for name, score in [("carat1", 50), ("carat2", 90)]:
            res = self.client.post("/api/scores/", {"game": "memory", "player": name, "score": score})
            self.assertEqual(res.status_code, 201)
        res = self.client.get("/api/scores/?game=memory")
        self.assertEqual([s["player"] for s in res.data], ["carat2", "carat1"])

    def test_rejects_blank_player(self):
        res = self.client.post("/api/scores/", {"game": "memory", "player": "  ", "score": 5})
        self.assertEqual(res.status_code, 400)
