import { useState } from 'react'
import { NavLink, Link } from 'react-router-dom'
import { useTheme } from '../lib/theme'

const LINKS = [
  { to: '/', label: 'Home', end: true },
  { to: '/members', label: 'Members' },
  { to: '/discography', label: 'Eras' },
  { to: '/games', label: 'Games' },
]

export function Nav() {
  const { pinned, pin } = useTheme()
  const [open, setOpen] = useState(false)

  return (
    <header className="nav">
      <Link to="/" className="nav__logo" onClick={() => setOpen(false)}>
        <img src="/diamond.svg" alt="" width={22} height={22} />
        <span>SVT</span>
      </Link>

      <button className="nav__burger" aria-label="Menu" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        <span />
        <span />
      </button>

      <nav className={`nav__links ${open ? 'is-open' : ''}`}>
        {LINKS.map((l) => (
          <NavLink key={l.to} to={l.to} end={l.end} onClick={() => setOpen(false)}>
            {l.label}
          </NavLink>
        ))}
      </nav>

      {pinned && (
        <button className="chip nav__era" onClick={() => pin(null)} title="Go back to the Rose Quartz & Serenity theme">
          Wearing <b>{pinned.label}</b> ✕
        </button>
      )}
    </header>
  )
}
