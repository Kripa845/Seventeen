from django.db import models


class Member(models.Model):
    class Unit(models.TextChoices):
        HIPHOP = "hiphop", "Hip-hop Unit"
        VOCAL = "vocal", "Vocal Unit"
        PERFORMANCE = "performance", "Performance Unit"

    slug = models.SlugField(unique=True)
    stage_name = models.CharField(max_length=50)
    birth_name = models.CharField(max_length=100)
    birthday = models.DateField()
    birthplace = models.CharField(max_length=100, blank=True)
    unit = models.CharField(max_length=20, choices=Unit.choices)
    is_unit_leader = models.BooleanField(default=False)
    position = models.CharField(max_length=150, blank=True)
    # Design choices for this site (not official): used for member themes.
    color = models.CharField(max_length=7, help_text="Hex colour, e.g. #F7CAC9")
    symbol = models.CharField(max_length=8, blank=True, help_text="An emoji used on cards")
    tagline = models.CharField(max_length=200, blank=True)
    fun_facts = models.JSONField(default=list, blank=True)
    photo = models.ImageField(upload_to="members/", blank=True, null=True)
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        ordering = ["order"]

    def __str__(self):
        return self.stage_name


class Album(models.Model):
    class Kind(models.TextChoices):
        MINI = "mini", "Mini album"
        STUDIO = "studio", "Studio album"
        REPACKAGE = "repackage", "Repackage"
        SPECIAL = "special", "Special album"
        BEST = "best", "Best album"
        SINGLE = "single", "Single album"

    slug = models.SlugField(unique=True)
    title = models.CharField(max_length=100)
    kind = models.CharField(max_length=20, choices=Kind.choices)
    release_date = models.DateField()
    title_track = models.CharField(max_length=100)
    era_mood = models.CharField(max_length=200, blank=True)
    # Theme tokens the frontend turns into CSS variables.
    theme = models.JSONField(
        default=dict,
        help_text='{"bg": "#..", "surface": "#..", "text": "#..", "accent": "#..", "accent2": "#..", "font": "serif|sans|display|mono", "pattern": "sparkle|grid|waves|stars|petals|none", "dark": false}',
    )
    cover = models.ImageField(upload_to="albums/", blank=True, null=True)

    class Meta:
        ordering = ["release_date"]

    def __str__(self):
        return self.title


class Song(models.Model):
    album = models.ForeignKey(Album, related_name="songs", on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    is_title_track = models.BooleanField(default=False)
    track_number = models.PositiveSmallIntegerField(default=1)
    youtube_url = models.URLField(blank=True, help_text="Paste the official MV link")
    spotify_url = models.URLField(blank=True, help_text="Paste the Spotify track link")

    class Meta:
        ordering = ["album__release_date", "track_number"]

    def __str__(self):
        return f"{self.title} ({self.album.title})"


class GameScore(models.Model):
    class Game(models.TextChoices):
        MEMORY = "memory", "Memory Match"
        UNIT_SORT = "unit_sort", "Unit Sorter"
        GUESS = "guess", "Guess the Member"

    game = models.CharField(max_length=20, choices=Game.choices)
    player = models.CharField(max_length=30)
    score = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-score", "created_at"]

    def __str__(self):
        return f"{self.player} – {self.game}: {self.score}"
