import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// During development, /api and /media are forwarded to Django on port 8000,
// so the browser never has to deal with CORS.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': 'http://127.0.0.1:8000',
      '/media': 'http://127.0.0.1:8000',
    },
  },
})
