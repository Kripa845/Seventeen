import { Link, useParams } from 'react-router-dom'
import { ApiError, Loading } from '../components/Status'
import { useAlbum, useAlbums } from '../lib/api'
import { formatDate } from '../lib/dates'
import { usePlayer } from '../lib/player'
import { usePageTheme, useTheme } from '../lib/theme'

export function AlbumDetail() {
  const { slug = '' } = useParams()
  const { data: a, error, loading } = useAlbum(slug)
  const all = useAlbums()
  const { pinned, pin } = useTheme()
  const { play, current } = usePlayer()
  usePageTheme(a?.theme)

  if (loading) return <Loading />
  if (error || !a) return <ApiError message={error ?? 'Not found'} />

  const songs = a.songs ?? []
  const wearing = pinned?.label === a.title
  const list = all.data ?? []
  const i = list.findIndex((x) => x.slug === a.slug)
  const prev = i > 0 ? list[i - 1] : null
  const next = i >= 0 && i < list.length - 1 ? list[i + 1] : null

  return (
    <article className="album">
      <Link className="link-arrow back" to="/discography">← All eras</Link>

      <header className="album__hero">
        <div className="album__art">
          {a.cover ? <img src={a.cover} alt={`${a.title} cover`} /> : <div className="album__orb" aria-hidden />}
        </div>
        <div>
          <p className="eyebrow">
            {a.kind_label} · {formatDate(a.release_date)}
          </p>
          <h1 className="album__title">{a.title}</h1>
          <p className="album__mood">{a.era_mood}</p>
          <div className="hero__ctas">
            {songs[0] && (
              <button className="btn" onClick={() => play(songs[0], songs)}>
                ▶ Play “{a.title_track}”
              </button>
            )}
            <button
              className="btn btn--ghost"
              onClick={() => pin(wearing ? null : { label: a.title, tokens: a.theme })}
            >
              {wearing ? 'Stop wearing this era' : '✦ Wear this era site-wide'}
            </button>
          </div>
        </div>
      </header>

      <section className="card">
        <h3>Tracks</h3>
        <ol className="tracks">
          {songs.map((s) => (
            <li key={s.id} className={current?.id === s.id ? 'is-playing' : ''}>
              <button onClick={() => play(s, songs)}>
                <span className="tracks__num">{s.track_number}</span>
                <span className="tracks__title">{s.title}</span>
                {s.is_title_track && <span className="chip chip--small">Title</span>}
                <span className="tracks__play" aria-hidden>{current?.id === s.id ? '♫' : '▶'}</span>
              </button>
            </li>
          ))}
        </ol>
        <p className="muted small">
          Add the other tracks and their YouTube/Spotify links in Django admin → Albums → {a.title}.
        </p>
      </section>

      <section className="palette card">
        <h3>Era palette</h3>
        <div className="palette__row">
          {(['bg', 'surface', 'text', 'accent', 'accent2'] as const).map((k) => (
            <div key={k} className="palette__swatch">
              <span style={{ background: a.theme[k] }} />
              <code>{a.theme[k]}</code>
            </div>
          ))}
        </div>
      </section>

      <nav className="profile__pager">
        {prev ? <Link to={`/discography/${prev.slug}`}>← {prev.title}</Link> : <span />}
        {next ? <Link to={`/discography/${next.slug}`}>{next.title} →</Link> : <span />}
      </nav>
    </article>
  )
}
