from rest_framework import serializers

from .models import Album, GameScore, Member, Song


class MemberSerializer(serializers.ModelSerializer):
    unit_label = serializers.CharField(source="get_unit_display", read_only=True)

    class Meta:
        model = Member
        fields = [
            "id", "slug", "stage_name", "birth_name", "birthday", "birthplace",
            "unit", "unit_label", "is_unit_leader", "position", "color", "symbol",
            "tagline", "fun_facts", "photo", "order",
        ]


class SongSerializer(serializers.ModelSerializer):
    album_title = serializers.CharField(source="album.title", read_only=True)
    album_slug = serializers.CharField(source="album.slug", read_only=True)

    class Meta:
        model = Song
        fields = [
            "id", "title", "is_title_track", "track_number", "youtube_url",
            "spotify_url", "album_title", "album_slug",
        ]


class AlbumListSerializer(serializers.ModelSerializer):
    kind_label = serializers.CharField(source="get_kind_display", read_only=True)

    class Meta:
        model = Album
        fields = [
            "id", "slug", "title", "kind", "kind_label", "release_date",
            "title_track", "era_mood", "theme", "cover",
        ]


class AlbumDetailSerializer(AlbumListSerializer):
    songs = SongSerializer(many=True, read_only=True)

    class Meta(AlbumListSerializer.Meta):
        fields = AlbumListSerializer.Meta.fields + ["songs"]


class GameScoreSerializer(serializers.ModelSerializer):
    class Meta:
        model = GameScore
        fields = ["id", "game", "player", "score", "created_at"]
        read_only_fields = ["id", "created_at"]

    def validate_player(self, value):
        value = value.strip()
        if not value:
            raise serializers.ValidationError("Enter a name.")
        return value

    def validate_score(self, value):
        if value < 0 or value > 100000:
            raise serializers.ValidationError("Score out of range.")
        return value
