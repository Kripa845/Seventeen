from django.contrib import admin

from .models import Album, GameScore, Member, Song


@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):
    list_display = ["stage_name", "birth_name", "unit", "birthday", "order"]
    list_filter = ["unit"]
    list_editable = ["order"]
    prepopulated_fields = {"slug": ["stage_name"]}


class SongInline(admin.TabularInline):
    model = Song
    extra = 1
    fields = ["track_number", "title", "is_title_track", "youtube_url", "spotify_url"]


@admin.register(Album)
class AlbumAdmin(admin.ModelAdmin):
    list_display = ["title", "kind", "release_date", "title_track"]
    list_filter = ["kind"]
    prepopulated_fields = {"slug": ["title"]}
    inlines = [SongInline]


@admin.register(Song)
class SongAdmin(admin.ModelAdmin):
    list_display = ["title", "album", "is_title_track", "youtube_url"]
    list_filter = ["is_title_track", "album"]
    search_fields = ["title"]


@admin.register(GameScore)
class GameScoreAdmin(admin.ModelAdmin):
    list_display = ["player", "game", "score", "created_at"]
    list_filter = ["game"]
