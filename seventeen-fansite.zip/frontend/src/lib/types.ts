export type Unit = 'hiphop' | 'vocal' | 'performance'

export interface Member {
  id: number
  slug: string
  stage_name: string
  birth_name: string
  birthday: string // YYYY-MM-DD
  birthplace: string
  unit: Unit
  unit_label: string
  is_unit_leader: boolean
  position: string
  color: string
  symbol: string
  tagline: string
  fun_facts: string[]
  photo: string | null
  order: number
}

export interface ThemeTokens {
  bg: string
  surface: string
  text: string
  accent: string
  accent2: string
  font: 'serif' | 'sans' | 'display' | 'mono'
  pattern: 'sparkle' | 'grid' | 'waves' | 'stars' | 'petals' | 'none'
  dark: boolean
}

export interface Song {
  id: number
  title: string
  is_title_track: boolean
  track_number: number
  youtube_url: string
  spotify_url: string
  album_title: string
  album_slug: string
}

export interface Album {
  id: number
  slug: string
  title: string
  kind: string
  kind_label: string
  release_date: string
  title_track: string
  era_mood: string
  theme: ThemeTokens
  cover: string | null
  songs?: Song[]
}

export type GameKey = 'memory' | 'unit_sort' | 'guess'

export interface Score {
  id: number
  game: GameKey
  player: string
  score: number
  created_at: string
}
