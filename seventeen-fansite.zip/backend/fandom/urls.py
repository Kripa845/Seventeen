from rest_framework.routers import DefaultRouter

from .views import AlbumViewSet, GameScoreViewSet, MemberViewSet, SongViewSet

router = DefaultRouter()
router.register("members", MemberViewSet, basename="member")
router.register("albums", AlbumViewSet, basename="album")
router.register("songs", SongViewSet, basename="song")
router.register("scores", GameScoreViewSet, basename="score")

urlpatterns = router.urls
