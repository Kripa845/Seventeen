import type { ThemeTokens } from './types'

function toRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '')
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  const n = parseInt(full, 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

function toHex([r, g, b]: number[]): string {
  return '#' + [r, g, b].map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('')
}

/** Mix colour a toward colour b by t (0 = a, 1 = b). */
export function mix(a: string, b: string, t: number): string {
  const A = toRgb(a)
  const B = toRgb(b)
  return toHex(A.map((v, i) => v + (B[i] - v) * t))
}

export function luminance(hex: string): number {
  const [r, g, b] = toRgb(hex).map((v) => {
    const c = v / 255
    return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4
  })
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

/** Black or white, whichever reads better on top of `hex`. */
export function readableOn(hex: string): string {
  return luminance(hex) > 0.45 ? '#1a1620' : '#ffffff'
}

/** Darken a colour until white text on it is readable (roughly 4.5:1). */
export function deepen(hex: string): string {
  let c = hex
  for (let i = 0; i < 12 && luminance(c) > 0.18; i++) c = mix(c, '#2a1f33', 0.12)
  return c
}

export function memberTheme(color: string): ThemeTokens {
  return {
    bg: mix(color, '#ffffff', 0.86),
    surface: '#ffffff',
    text: '#2b2433',
    accent: deepen(color),
    accent2: color,
    font: 'serif',
    pattern: 'sparkle',
    dark: false,
  }
}

/** The default look: CARAT's Rose Quartz & Serenity. */
export const CARAT_THEME: ThemeTokens = {
  bg: '#FBF6F8',
  surface: '#FFFFFF',
  text: '#2E2A3B',
  accent: '#C25E73',
  accent2: '#7D93C9',
  font: 'serif',
  pattern: 'sparkle',
  dark: false,
}
