# SEVENTEEN fan site ◆

An aesthetic, unofficial fan site for SEVENTEEN and CARATs.

- **frontend/**: React + Vite + TypeScript
- **backend/**: Python Django + Django REST Framework (SQLite)

## Features (v1)

- **Era themes**: every album has its own palette, heading font and background pattern. Opening an album page restyles the whole site, and you can click "Wear this era site-wide" to keep it (saved in the browser).
- **Member themes**: each member's profile page switches to their colour.
- **Members**: flip cards grouped by unit, plus profile pages with a birthday countdown and fun facts.
- **Discography timeline**: 21 releases, from *17 Carat* (2015) to *Happy Burstday* (2025).
- **Mini music player**: keeps playing while you move between pages. It plays YouTube MVs or Spotify links that you add in admin.
- **Games**: Memory Match, Unit Sorter, Guess the Member, each with a CARAT leaderboard stored in Django.
- **Home**: days since debut, anniversary countdown, next member birthday, member of the day.
- **Small touches**: sparkle cursor trail and glassy cards. It works on phones and respects "reduce motion".

## Run it (Windows)

You need **Python 3.10+** and **Node 18+**. Use two terminals.

### 1. Backend (terminal 1)

```powershell
cd backend
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_svt          # loads the 13 members + 21 albums
python manage.py createsuperuser   # for the admin panel
python manage.py runserver
```

- API: http://127.0.0.1:8000/api/
- Admin: http://127.0.0.1:8000/admin/

### 2. Frontend (terminal 2)

```powershell
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**. Vite forwards `/api` and `/media` to Django, so both must be running.

## Making it yours (through Django admin)

| What | Where |
|---|---|
| Member photos | Admin → Members → upload **Photo** (otherwise the card shows the member's emoji) |
| Album covers | Admin → Albums → **Cover** |
| Make songs play | Admin → Albums → pick an album → in **Songs**, paste the official YouTube MV link or the Spotify track link. Until then, the player shows SEVENTEEN's Spotify artist page. |
| More tracks | Same place: add rows to the Songs table |
| New comeback | Admin → Albums → Add, and set the `theme` JSON (copy one from another album) |

Theme JSON example:

```json
{"bg": "#0B0F24", "surface": "#141A3A", "text": "#EAF0FF", "accent": "#FFD400",
 "accent2": "#6AA8FF", "font": "display", "pattern": "stars", "dark": true}
```

`font`: `serif | sans | display | mono` · `pattern`: `sparkle | grid | waves | stars | petals | none`

Starter data lives in `backend/fandom/seed/*.json`. Running `seed_svt` again updates members and albums, and keeps the song links you added in admin. The member colours and emoji are design choices for this site, not official ones. Double-check facts and edit freely.

## API

| Method | Endpoint | Notes |
|---|---|---|
| GET | `/api/members/` | `?unit=hiphop\|vocal\|performance` |
| GET | `/api/members/<slug>/` | e.g. `hoshi` |
| GET | `/api/albums/` | ordered by release date |
| GET | `/api/albums/<slug>/` | includes `songs` |
| GET | `/api/songs/` | `?title_tracks=1` |
| GET | `/api/scores/?game=memory` | top 10 (`memory`, `unit_sort`, `guess`) |
| POST | `/api/scores/` | `{"game": "memory", "player": "name", "score": 1200}` |

Tests: `python manage.py test fandom`

## Project map

```
backend/
  config/            settings & urls
  fandom/            models, serializers, views, admin, tests
    seed/            members.json, albums.json
    management/commands/seed_svt.py
frontend/src/
  lib/               api, theme (era/member themes), player, colour & date helpers
  components/        Nav, MiniPlayer, SparkleTrail, MemberAvatar, Leaderboard
  pages/             Home, Members, MemberDetail, Discography, AlbumDetail, Games
  pages/games/       MemoryMatch, UnitSorter, GuessMember
  index.css          all styles (driven by CSS variables)
```

## Ideas for next

- Photocard gacha: one random card a day, collected in a binder
- Guess the song from a short preview
- "Which member are you?" quiz with a shareable result card
- CARAT lightstick simulator
- Concert / dark mode toggle
- Member birthday banners on the home page

## Copyright

Use official photos with credit and don't upload song audio files or lyrics. Music plays through official YouTube/Spotify embeds. SEVENTEEN © PLEDIS Entertainment. This is a fan project.
