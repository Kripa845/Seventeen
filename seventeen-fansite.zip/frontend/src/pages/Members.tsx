import { useState } from 'react'
import { Link } from 'react-router-dom'
import { MemberAvatar } from '../components/MemberAvatar'
import { ApiError, Loading } from '../components/Status'
import { useMembers } from '../lib/api'
import { formatDate } from '../lib/dates'
import type { Member, Unit } from '../lib/types'

const UNITS: { key: Unit; name: string; blurb: string }[] = [
  { key: 'hiphop', name: 'Hip-hop Unit', blurb: 'The rap line: flow, swagger and attitude.' },
  { key: 'vocal', name: 'Vocal Unit', blurb: 'The voices behind every ballad and high note.' },
  { key: 'performance', name: 'Performance Unit', blurb: 'The dancers who make the choreography unforgettable.' },
]

function FlipCard({ m }: { m: Member }) {
  const [flipped, setFlipped] = useState(false)
  return (
    <div className={`flip ${flipped ? 'is-flipped' : ''}`} style={{ ['--m' as string]: m.color }}>
      <button className="flip__inner" onClick={() => setFlipped((f) => !f)} aria-label={`${m.stage_name}: flip card`}>
        <div className="flip__face flip__front">
          <MemberAvatar member={m} />
          <h3>{m.stage_name}</h3>
          <p className="muted">{m.position}</p>
          {m.is_unit_leader && <span className="chip chip--small">Unit leader</span>}
        </div>
        <div className="flip__face flip__back">
          <dl>
            <dt>Name</dt>
            <dd>{m.birth_name}</dd>
            <dt>Birthday</dt>
            <dd>{formatDate(m.birthday)}</dd>
            <dt>Hometown</dt>
            <dd>{m.birthplace}</dd>
          </dl>
          <p className="flip__tagline">“{m.tagline}”</p>
        </div>
      </button>
      <Link className="flip__more" to={`/members/${m.slug}`}>
        Profile →
      </Link>
    </div>
  )
}

export function Members() {
  const { data, error, loading } = useMembers()
  const [filter, setFilter] = useState<Unit | 'all'>('all')

  return (
    <div>
      <header className="page-head">
        <p className="eyebrow">13 members · 3 units</p>
        <h1>The members</h1>
        <p className="muted">Tap a card to flip it. Open a profile to see the site change into that member's colour.</p>
        <div className="tabs" role="tablist">
          {(['all', 'hiphop', 'vocal', 'performance'] as const).map((k) => (
            <button key={k} role="tab" aria-selected={filter === k} className={filter === k ? 'is-active' : ''} onClick={() => setFilter(k)}>
              {k === 'all' ? 'All' : UNITS.find((u) => u.key === k)!.name.replace(' Unit', '')}
            </button>
          ))}
        </div>
      </header>

      {loading && <Loading />}
      {error && <ApiError message={error} />}

      {data &&
        UNITS.filter((u) => filter === 'all' || filter === u.key).map((u) => (
          <section key={u.key} className="unit">
            <div className="unit__head">
              <h2>{u.name}</h2>
              <p className="muted">{u.blurb}</p>
            </div>
            <div className="member-grid">
              {data
                .filter((m) => m.unit === u.key)
                .map((m) => (
                  <FlipCard key={m.slug} m={m} />
                ))}
            </div>
          </section>
        ))}
    </div>
  )
}
