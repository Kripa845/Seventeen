import { Link } from 'react-router-dom'
import { MemberAvatar } from '../components/MemberAvatar'
import { ApiError, Loading } from '../components/Status'
import { useAlbums, useMembers } from '../lib/api'
import { dailyIndex, DEBUT, daysSince, formatDayMonth, nextAnniversary } from '../lib/dates'

export function Home() {
  const members = useMembers()
  const albums = useAlbums()

  const anniversary = nextAnniversary('2015-05-26')
  const nextBirthday = members.data
    ?.map((m) => ({ m, ...nextAnniversary(m.birthday) }))
    .sort((a, b) => a.days - b.days)[0]
  const todays = members.data?.[dailyIndex(members.data.length)]
  const latest = albums.data?.slice(-4).reverse()

  return (
    <div className="home">
      <section className="hero">
        <p className="eyebrow">for CARAT, since 2015</p>
        <h1 className="hero__title">
          SEVENTEEN
          <span className="hero__equation" aria-label="13 members, 3 units, 1 team">
            13 <i>+</i> 3 <i>+</i> 1
          </span>
        </h1>
        <p className="hero__lede">
          Thirteen members, three units, one team. Wander through every era, meet the boys, and play a little.
        </p>
        <div className="hero__ctas">
          <Link className="btn" to="/members">Meet the members</Link>
          <Link className="btn btn--ghost" to="/discography">Explore the eras</Link>
        </div>
      </section>

      <section className="stats">
        <div className="stat card">
          <span className="stat__num">{daysSince(DEBUT).toLocaleString()}</span>
          <span className="stat__label">days since debut</span>
        </div>
        <div className="stat card">
          <span className="stat__num">{anniversary.days === 0 ? '🎉' : anniversary.days}</span>
          <span className="stat__label">{anniversary.days === 0 ? 'Happy anniversary!' : 'days to the anniversary'}</span>
        </div>
        {nextBirthday && (
          <Link to={`/members/${nextBirthday.m.slug}`} className="stat card">
            <span className="stat__num">{nextBirthday.days === 0 ? '🎂' : nextBirthday.days}</span>
            <span className="stat__label">
              {nextBirthday.days === 0
                ? `Happy birthday, ${nextBirthday.m.stage_name}!`
                : `days to ${nextBirthday.m.stage_name}'s birthday · ${formatDayMonth(nextBirthday.date)}`}
            </span>
          </Link>
        )}
      </section>

      {members.error && <ApiError message={members.error} />}

      {todays && (
        <section className="today card" style={{ ['--m' as string]: todays.color }}>
          <MemberAvatar member={todays} size="lg" />
          <div>
            <p className="eyebrow">Member of the day</p>
            <h2>{todays.stage_name}</h2>
            <p className="today__tagline">{todays.tagline}</p>
            <Link className="link-arrow" to={`/members/${todays.slug}`}>Visit {todays.stage_name}'s page →</Link>
          </div>
        </section>
      )}

      <section>
        <div className="section-head">
          <h2>Latest eras</h2>
          <Link className="link-arrow" to="/discography">All eras →</Link>
        </div>
        {albums.loading && <Loading />}
        <div className="era-grid">
          {latest?.map((a) => (
            <Link
              key={a.slug}
              to={`/discography/${a.slug}`}
              className="era-tile"
              style={{ background: a.theme.bg, color: a.theme.text, ['--a' as string]: a.theme.accent, ['--a2' as string]: a.theme.accent2 }}
            >
              <span className="era-tile__orb" aria-hidden />
              <span className="era-tile__year">{a.release_date.slice(0, 4)}</span>
              <span className="era-tile__title">{a.title}</span>
              <span className="era-tile__track">♪ {a.title_track}</span>
            </Link>
          ))}
        </div>
      </section>

      <section className="games-teaser card">
        <div>
          <h2>Play with SEVENTEEN</h2>
          <p className="muted">Memory match, unit sorter and guess-the-member, with a CARAT leaderboard.</p>
        </div>
        <Link className="btn" to="/games">Play now</Link>
      </section>
    </div>
  )
}
