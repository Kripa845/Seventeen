import { useEffect, useState } from 'react'
import type { Album, GameKey, Member, Score, Song } from './types'

const BASE = import.meta.env.VITE_API_URL ?? '/api'

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`)
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`)
  return res.json() as Promise<T>
}

// Small in-memory cache so moving between pages doesn't refetch everything.
const cache = new Map<string, unknown>()

export function useApi<T>(path: string | null) {
  const [data, setData] = useState<T | null>(path ? ((cache.get(path) as T) ?? null) : null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!path) return
    let alive = true
    const cached = cache.get(path) as T | undefined
    setData(cached ?? null)
    setError(null)
    if (cached) return
    get<T>(path)
      .then((d) => {
        cache.set(path, d)
        if (alive) setData(d)
      })
      .catch((e: Error) => alive && setError(e.message))
    return () => {
      alive = false
    }
  }, [path])

  return { data, error, loading: !data && !error }
}

export const useMembers = () => useApi<Member[]>('/members/')
export const useMember = (slug: string) => useApi<Member>(`/members/${slug}/`)
export const useAlbums = () => useApi<Album[]>('/albums/')
export const useAlbum = (slug: string) => useApi<Album>(`/albums/${slug}/`)
export const useTitleTracks = () => useApi<Song[]>('/songs/?title_tracks=1')

export async function fetchScores(game: GameKey): Promise<Score[]> {
  return get<Score[]>(`/scores/?game=${game}`)
}

export async function postScore(game: GameKey, player: string, score: number): Promise<Score> {
  const res = await fetch(`${BASE}/scores/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ game, player, score }),
  })
  if (!res.ok) throw new Error('Could not save score')
  return res.json()
}
