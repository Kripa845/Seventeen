import { Link, useParams } from 'react-router-dom'
import { MemberAvatar } from '../components/MemberAvatar'
import { ApiError, Loading } from '../components/Status'
import { useMember, useMembers } from '../lib/api'
import { memberTheme } from '../lib/color'
import { ageOn, formatDate, nextAnniversary } from '../lib/dates'
import { usePageTheme } from '../lib/theme'

export function MemberDetail() {
  const { slug = '' } = useParams()
  const { data: m, error, loading } = useMember(slug)
  const all = useMembers()
  usePageTheme(m ? memberTheme(m.color) : null)

  if (loading) return <Loading />
  if (error || !m) return <ApiError message={error ?? 'Not found'} />

  const bday = nextAnniversary(m.birthday)
  const list = all.data ?? []
  const i = list.findIndex((x) => x.slug === m.slug)
  const prev = list.length ? list[(i - 1 + list.length) % list.length] : null
  const next = list.length ? list[(i + 1) % list.length] : null

  return (
    <article className="profile">
      <Link className="link-arrow back" to="/members">← All members</Link>

      <header className="profile__hero">
        <MemberAvatar member={m} size="lg" />
        <div>
          <p className="eyebrow">
            {m.unit_label}
            {m.is_unit_leader && ' · Leader'}
          </p>
          <h1 className="profile__name">
            {m.stage_name} <span aria-hidden>{m.symbol}</span>
          </h1>
          <p className="profile__tagline">{m.tagline}</p>
        </div>
      </header>

      <div className="profile__grid">
        <section className="card">
          <h3>Profile</h3>
          <dl className="facts">
            <dt>Birth name</dt>
            <dd>{m.birth_name}</dd>
            <dt>Birthday</dt>
            <dd>
              {formatDate(m.birthday)} · {ageOn(m.birthday)} years old
            </dd>
            <dt>Hometown</dt>
            <dd>{m.birthplace}</dd>
            <dt>Position</dt>
            <dd>{m.position}</dd>
          </dl>
        </section>

        <section className="card profile__countdown">
          <span className="stat__num">{bday.days === 0 ? '🎂' : bday.days}</span>
          <span className="stat__label">{bday.days === 0 ? 'Happy birthday!' : 'days until the next birthday'}</span>
        </section>

        <section className="card profile__facts">
          <h3>Fun facts</h3>
          <ul>
            {m.fun_facts.map((f) => (
              <li key={f}>{f}</li>
            ))}
          </ul>
        </section>
      </div>

      {prev && next && (
        <nav className="profile__pager">
          <Link to={`/members/${prev.slug}`}>← {prev.stage_name}</Link>
          <Link to={`/members/${next.slug}`}>{next.stage_name} →</Link>
        </nav>
      )}
    </article>
  )
}
