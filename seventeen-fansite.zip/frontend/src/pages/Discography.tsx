import { Link } from 'react-router-dom'
import { ApiError, Loading } from '../components/Status'
import { useAlbums } from '../lib/api'

export function Discography() {
  const { data, error, loading } = useAlbums()

  return (
    <div>
      <header className="page-head">
        <p className="eyebrow">2015 → now</p>
        <h1>Every era</h1>
        <p className="muted">Scroll the timeline. Each era has its own colours and mood; step inside one to see the whole site change.</p>
      </header>

      {loading && <Loading />}
      {error && <ApiError message={error} />}

      <ol className="timeline">
        {data?.map((a) => (
          <li key={a.slug} className="timeline__item">
            <span className="timeline__dot" style={{ background: a.theme.accent }} aria-hidden />
            <Link
              to={`/discography/${a.slug}`}
              className="era-card"
              style={{
                background: a.theme.bg,
                color: a.theme.text,
                ['--a' as string]: a.theme.accent,
                ['--a2' as string]: a.theme.accent2,
              }}
            >
              {a.cover ? <img className="era-card__cover" src={a.cover} alt="" /> : <span className="era-card__orb" aria-hidden />}
              <span className="era-card__kind">{a.kind_label} · {a.release_date.slice(0, 4)}</span>
              <span className={`era-card__title font-${a.theme.font}`}>{a.title}</span>
              <span className="era-card__track">♪ {a.title_track}</span>
              <span className="era-card__mood">{a.era_mood}</span>
            </Link>
          </li>
        ))}
      </ol>
    </div>
  )
}
