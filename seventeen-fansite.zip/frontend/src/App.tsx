import { useEffect } from 'react'
import { BrowserRouter, Link, Route, Routes, useLocation } from 'react-router-dom'
import { MiniPlayer } from './components/MiniPlayer'
import { Nav } from './components/Nav'
import { SparkleTrail } from './components/SparkleTrail'
import { PlayerProvider } from './lib/player'
import { ThemeProvider } from './lib/theme'
import { AlbumDetail } from './pages/AlbumDetail'
import { Discography } from './pages/Discography'
import { Games } from './pages/Games'
import { Home } from './pages/Home'
import { MemberDetail } from './pages/MemberDetail'
import { Members } from './pages/Members'

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => window.scrollTo(0, 0), [pathname])
  return null
}

function NotFound() {
  return (
    <div className="page-head">
      <h1>Lost in the 17th dimension</h1>
      <p className="muted">That page doesn't exist.</p>
      <Link className="btn" to="/">Back home</Link>
    </div>
  )
}

export default function App() {
  return (
    <ThemeProvider>
      <PlayerProvider>
        <BrowserRouter>
          <ScrollToTop />
          <SparkleTrail />
          <div className="bg-pattern" aria-hidden />
          <Nav />
          <main className="main">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/members" element={<Members />} />
              <Route path="/members/:slug" element={<MemberDetail />} />
              <Route path="/discography" element={<Discography />} />
              <Route path="/discography/:slug" element={<AlbumDetail />} />
              <Route path="/games" element={<Games />} />
              <Route path="/games/:game" element={<Games />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <footer className="footer">
            Made with ◆ by a CARAT · Unofficial fan site · Music via YouTube & Spotify embeds · SEVENTEEN © PLEDIS Entertainment
          </footer>
          <MiniPlayer />
        </BrowserRouter>
      </PlayerProvider>
    </ThemeProvider>
  )
}
