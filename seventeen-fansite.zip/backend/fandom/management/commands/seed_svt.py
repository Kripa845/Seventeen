import json
from pathlib import Path

from django.core.management.base import BaseCommand
from django.db import transaction

from fandom.models import Album, Member, Song

SEED_DIR = Path(__file__).resolve().parents[2] / "seed"


class Command(BaseCommand):
    help = "Load SEVENTEEN members, albums and title tracks. Safe to run again (updates, never deletes)."

    @transaction.atomic
    def handle(self, *args, **options):
        members = json.loads((SEED_DIR / "members.json").read_text(encoding="utf-8"))
        for i, data in enumerate(members):
            slug = data.pop("slug")
            Member.objects.update_or_create(slug=slug, defaults={**data, "order": i})

        albums = json.loads((SEED_DIR / "albums.json").read_text(encoding="utf-8"))
        for data in albums:
            slug = data.pop("slug")
            album, _ = Album.objects.update_or_create(slug=slug, defaults=data)
            # Only creates the title track if missing, so links you add in admin are kept.
            Song.objects.get_or_create(
                album=album,
                title=album.title_track,
                defaults={"is_title_track": True, "track_number": 1},
            )

        self.stdout.write(self.style.SUCCESS(
            f"Seeded {Member.objects.count()} members, {Album.objects.count()} albums, {Song.objects.count()} songs."
        ))
