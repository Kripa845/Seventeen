import { createContext, useContext, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { Song } from './types'

// SEVENTEEN's artist page on Spotify, used when a song has no link yet.
export const SPOTIFY_ARTIST_ID = '7nqOGRxlXj7N2JYbgNEjYH'

interface PlayerCtx {
  current: Song | null
  queue: Song[]
  play: (song: Song, queue?: Song[]) => void
  next: () => void
  prev: () => void
  close: () => void
}

const Ctx = createContext<PlayerCtx | null>(null)

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [queue, setQueue] = useState<Song[]>([])
  const [index, setIndex] = useState(-1)
  const current = index >= 0 ? queue[index] ?? null : null

  const value = useMemo<PlayerCtx>(
    () => ({
      current,
      queue,
      play: (song, q) => {
        const list = q && q.length ? q : [song]
        setQueue(list)
        setIndex(Math.max(0, list.findIndex((s) => s.id === song.id)))
      },
      next: () => setIndex((i) => (queue.length ? (i + 1) % queue.length : -1)),
      prev: () => setIndex((i) => (queue.length ? (i - 1 + queue.length) % queue.length : -1)),
      close: () => setIndex(-1),
    }),
    [current, queue],
  )

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function usePlayer() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('usePlayer must be inside PlayerProvider')
  return ctx
}

/** Accepts youtu.be/ID, youtube.com/watch?v=ID, /shorts/ID, /embed/ID */
export function youtubeId(url: string): string | null {
  if (!url) return null
  try {
    const u = new URL(url)
    if (u.hostname.includes('youtu.be')) return u.pathname.slice(1) || null
    if (u.searchParams.get('v')) return u.searchParams.get('v')
    const m = u.pathname.match(/\/(embed|shorts)\/([\w-]{6,})/)
    return m ? m[2] : null
  } catch {
    return null
  }
}

/** open.spotify.com/track/ID → embed URL */
export function spotifyEmbed(url: string): string | null {
  const m = url?.match(/open\.spotify\.com\/(?:intl-\w+\/)?(track|album|playlist)\/(\w+)/)
  return m ? `https://open.spotify.com/embed/${m[1]}/${m[2]}?utm_source=generator` : null
}
