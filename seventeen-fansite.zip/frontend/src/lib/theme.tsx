import { createContext, useContext, useEffect, useLayoutEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { CARAT_THEME, deepen, mix, readableOn } from './color'
import type { ThemeTokens } from './types'

/**
 * Two layers of theme:
 *  - pinned:   the era the visitor chose to "wear" site-wide (saved in localStorage)
 *  - override: a page's own look while you're on it (a member or album page)
 * The page override wins; leaving the page falls back to the pinned era.
 */
interface Pinned {
  label: string
  tokens: ThemeTokens
}

interface ThemeCtx {
  pinned: Pinned | null
  pin: (p: Pinned | null) => void
  setOverride: (t: ThemeTokens | null) => void
  active: ThemeTokens
}

const Ctx = createContext<ThemeCtx | null>(null)
const KEY = 'svt-pinned-era'

const FONTS: Record<ThemeTokens['font'], string> = {
  serif: "'Cormorant Garamond', Georgia, serif",
  sans: "'Plus Jakarta Sans', system-ui, sans-serif",
  display: "'Unbounded', 'Plus Jakarta Sans', sans-serif",
  mono: "'Space Mono', ui-monospace, monospace",
}

function loadPinned(): Pinned | null {
  try {
    const raw = localStorage.getItem(KEY)
    return raw ? (JSON.parse(raw) as Pinned) : null
  } catch {
    return null
  }
}

function applyTokens(t: ThemeTokens) {
  const root = document.documentElement
  // On dark themes the accent is used as-is; on light ones make sure text on it is readable.
  const accentStrong = t.dark ? t.accent : deepen(t.accent)
  const vars: Record<string, string> = {
    '--bg': t.bg,
    '--surface': t.surface,
    '--text': t.text,
    '--muted': mix(t.text, t.bg, 0.38),
    '--line': mix(t.text, t.bg, 0.86),
    '--accent': t.accent,
    '--accent-strong': accentStrong,
    '--on-accent': readableOn(accentStrong),
    '--accent2': t.accent2,
    '--glow': mix(t.accent, t.bg, 0.55),
    '--font-head': FONTS[t.font] ?? FONTS.serif,
  }
  for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v)
  root.dataset.pattern = t.pattern
  root.dataset.dark = String(t.dark)
  root.style.colorScheme = t.dark ? 'dark' : 'light'
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [pinned, setPinned] = useState<Pinned | null>(loadPinned)
  const [override, setOverride] = useState<ThemeTokens | null>(null)
  const active = override ?? pinned?.tokens ?? CARAT_THEME

  useLayoutEffect(() => applyTokens(active), [active])

  const value = useMemo<ThemeCtx>(
    () => ({
      pinned,
      active,
      setOverride,
      pin: (p) => {
        setPinned(p)
        try {
          if (p) localStorage.setItem(KEY, JSON.stringify(p))
          else localStorage.removeItem(KEY)
        } catch {
          /* storage blocked: still works for this visit */
        }
      },
    }),
    [pinned, active],
  )

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useTheme() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useTheme must be inside ThemeProvider')
  return ctx
}

/** Give the current page its own look; it is removed when the page unmounts. */
export function usePageTheme(tokens: ThemeTokens | null | undefined) {
  const { setOverride } = useTheme()
  const key = tokens ? JSON.stringify(tokens) : ''
  useEffect(() => {
    if (!key) return
    setOverride(JSON.parse(key) as ThemeTokens)
    return () => setOverride(null)
  }, [key, setOverride])
}
