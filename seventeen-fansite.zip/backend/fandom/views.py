from rest_framework import mixins, viewsets
from rest_framework.response import Response

from .models import Album, GameScore, Member, Song
from .serializers import (
    AlbumDetailSerializer,
    AlbumListSerializer,
    GameScoreSerializer,
    MemberSerializer,
    SongSerializer,
)


class MemberViewSet(viewsets.ReadOnlyModelViewSet):
    """GET /api/members/ and /api/members/<slug>/ ; filter with ?unit=vocal"""

    serializer_class = MemberSerializer
    lookup_field = "slug"

    def get_queryset(self):
        qs = Member.objects.all()
        unit = self.request.query_params.get("unit")
        return qs.filter(unit=unit) if unit else qs


class AlbumViewSet(viewsets.ReadOnlyModelViewSet):
    """GET /api/albums/ and /api/albums/<slug>/ (detail includes songs)"""

    queryset = Album.objects.prefetch_related("songs")
    lookup_field = "slug"

    def get_serializer_class(self):
        return AlbumDetailSerializer if self.action == "retrieve" else AlbumListSerializer


class SongViewSet(viewsets.ReadOnlyModelViewSet):
    """GET /api/songs/ ; ?title_tracks=1 for title tracks only"""

    serializer_class = SongSerializer

    def get_queryset(self):
        qs = Song.objects.select_related("album")
        if self.request.query_params.get("title_tracks"):
            qs = qs.filter(is_title_track=True)
        return qs


class GameScoreViewSet(mixins.CreateModelMixin, mixins.ListModelMixin, viewsets.GenericViewSet):
    """GET /api/scores/?game=memory (top 10)  ·  POST /api/scores/ {game, player, score}"""

    serializer_class = GameScoreSerializer
    pagination_class = None

    def get_queryset(self):
        qs = GameScore.objects.all()
        game = self.request.query_params.get("game")
        if game:
            qs = qs.filter(game=game)
        return qs

    def list(self, request, *args, **kwargs):
        data = self.get_serializer(self.get_queryset()[:10], many=True).data
        return Response(data)
