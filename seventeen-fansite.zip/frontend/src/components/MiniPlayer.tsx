import { useState } from 'react'
import { Link } from 'react-router-dom'
import { SPOTIFY_ARTIST_ID, spotifyEmbed, usePlayer, youtubeId } from '../lib/player'

/**
 * Lives in the layout, so music keeps playing while you move between pages.
 * Plays the song's YouTube MV if it has one, else its Spotify link,
 * else SEVENTEEN's Spotify artist page.
 */
export function MiniPlayer() {
  const { current, queue, next, prev, close } = usePlayer()
  const [big, setBig] = useState(false)
  if (!current) return null

  const yt = youtubeId(current.youtube_url)
  const sp = spotifyEmbed(current.spotify_url)
  const fallback = !yt && !sp

  let src: string
  if (yt) src = `https://www.youtube-nocookie.com/embed/${yt}?autoplay=1&rel=0`
  else if (sp) src = sp
  else src = `https://open.spotify.com/embed/artist/${SPOTIFY_ARTIST_ID}?utm_source=generator`

  return (
    <aside className={`player ${big ? 'is-big' : ''} ${yt ? 'is-video' : 'is-spotify'}`} aria-label="Music player">
      <div className="player__info">
        <span className="player__disc" aria-hidden>
          ◆
        </span>
        <div>
          <p className="player__title">{current.title}</p>
          <p className="player__meta">
            <Link to={`/discography/${current.album_slug}`}>{current.album_title}</Link>
            {fallback && <span> · no link yet, playing SEVENTEEN on Spotify</span>}
          </p>
        </div>
      </div>

      <iframe
        key={src}
        className="player__frame"
        src={src}
        title={`${current.title} player`}
        allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture"
        loading="lazy"
      />

      <div className="player__controls">
        {queue.length > 1 && (
          <>
            <button onClick={prev} aria-label="Previous">⏮</button>
            <button onClick={next} aria-label="Next">⏭</button>
          </>
        )}
        {yt && (
          <button onClick={() => setBig((b) => !b)} aria-label={big ? 'Shrink video' : 'Enlarge video'}>
            {big ? '▾' : '▴'}
          </button>
        )}
        <button onClick={close} aria-label="Close player">✕</button>
      </div>
    </aside>
  )
}
